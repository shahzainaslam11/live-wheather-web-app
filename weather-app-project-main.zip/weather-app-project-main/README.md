Weather App
This project is a simple weather application that allows users to input a city name and view its current weather details,
including temperature, humidity, wind speed, and weather icon. 
It uses the OpenWeatherMap API to fetch weather data dynamically.
